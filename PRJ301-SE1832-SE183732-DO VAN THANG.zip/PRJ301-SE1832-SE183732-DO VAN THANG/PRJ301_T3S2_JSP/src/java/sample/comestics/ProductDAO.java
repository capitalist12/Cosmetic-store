/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample.comestics;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NamingException;
import sample.user.UserDTO;
import sample.utils.DBUtils;

/**
 *
 * @author ASUS
 */
public class ProductDAO {
    
     private static final String GETPRODUCT = "SELECT productID, name, price, quantity FROM products WHERE quantity > 0 ";
     private static final String SAVETOORDER = "INSERT INTO [dbo].[order](userID, date, total, status) VALUES (?, GETDATE(), ?, 1)";
    private static final String SAVETOORDERDETAIL = "INSERT INTO [dbo].[orderDetail](orderID, productID, price, quantity, status) VALUES (?, ?, ?, ?, 1)";
    private static final String QUANTITY = "SELECT quantity FROM products WHERE productID = ?";
    private static final String UPDATE = "UPDATE products SET quantity=? WHERE productID=?";
    private static final String DELETE_PRODUCT = "DELETE products WHERE productID=?";
    private static final String UPDATE_PRODUCT = "UPDATE products SET name=?, price=?, quantity=? WHERE productID=? ";
    private static String CHECK_DUPELICATE = "SELECT name FROM products WHERE productID=?";
    private static String INSERT_PRODUCT = "INSERT INTO products(productID, name, price, quantity) VALUES(?,?,?,?)";
    private static final String SEARCH_PRODUCT = "SELECT productID, name, price, quantity FROM products WHERE name LIKE ?";
     
      public List<Comestics> getListProduct() throws SQLException, ClassNotFoundException, NamingException {
        List<Comestics> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(GETPRODUCT);
                rs = ptm.executeQuery();
                while (rs.next()) {
                    String id = rs.getString("productID");
                    String name = rs.getString("name");
                    double price = rs.getDouble("price");
                    int quantity = rs.getInt("quantity");
                    list.add(new Comestics(id, name, quantity, price));
                    
                }
            }        
        } finally {
            if (rs != null) rs.close();
            if (ptm != null) ptm.close();
            if (conn != null) conn.close();      
        }
        return list;
    }
      
      public List<Comestics> getListProductV2(String searchProduct) throws SQLException, ClassNotFoundException, NamingException {
        List<Comestics> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(SEARCH_PRODUCT);
                ptm.setString(1, "%" + searchProduct +"%");
                rs = ptm.executeQuery();
                while (rs.next()) {
                    String productID = rs.getString("productID");
                    String name = rs.getString("name");
                    double price = rs.getDouble("price");
                    int quantity = rs.getInt("quantity");
                    list.add(new Comestics(productID, name, quantity, price));
                }
            }        
        } finally {
            if (rs != null) rs.close();
            if (ptm != null) ptm.close();
            if (conn != null) conn.close();      
        }
        return list;
    }
      
      public boolean updateProduct(Comestics comestics) throws SQLException, ClassNotFoundException, NamingException {
        boolean check = false;
        Connection conn = null;
        PreparedStatement ptm = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(UPDATE_PRODUCT);
                ptm.setString(1, comestics.getName());
                ptm.setDouble(2, comestics.getPrice());
                ptm.setInt(3, comestics.getQuantity());
                ptm.setString(4, comestics.getId());
                
                check = ptm.executeUpdate() > 0 ? true : false;
            }       
        } finally {
            if (ptm != null) ptm.close();
            if (conn != null) conn.close();     
        }
        return check;
    }
      
      public boolean deleteProduct(String id) throws SQLException, ClassNotFoundException, NamingException {
        boolean check = false;
        Connection conn = null;
        PreparedStatement ptm = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(DELETE_PRODUCT);
                ptm.setString(1, id);
                check = ptm.executeUpdate() > 0 ? true : false;
            }       
        } finally {
            if (ptm != null) ptm.close();
            if (conn != null) conn.close();     
        }
        return check;
    }
      
      public boolean insertP(Comestics comestics) throws SQLException, ClassNotFoundException, NamingException{
        boolean check = false;
        Connection con = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try{
            con = DBUtils.getConnection();
            if(con != null){
                ptm = con.prepareStatement(INSERT_PRODUCT);               
                ptm.setString(1, comestics.getId());
                ptm.setString(2, comestics.getName());
                ptm.setDouble(3, comestics.getPrice());
                ptm.setInt(4, comestics.getQuantity());
                
                check = ptm.executeUpdate() > 0 ? true : false;
            }
        }finally{
            if(ptm != null){
                ptm.close();
            }
            if(con != null){
                con.close();
            }
            if(rs != null){
                rs.close();
            }
        }
        return check;
    }
      
      public boolean checkDupelicate(String id) throws SQLException, ClassNotFoundException, NamingException{
        boolean check = false;
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try{
            con = DBUtils.getConnection();
            if(con != null){
                stm = con.prepareStatement(CHECK_DUPELICATE);
                stm.setString(1, id);
                rs = stm.executeQuery();
                if(rs.next()){
                    check = true;
                }
            }
        }finally{
            if(stm != null){
                stm.close();
            }
            if(con != null){
                con.close();
            }
            if(rs != null){
                rs.close();
            }
        }
        return check;
    }

    public int saveToOrder(String userID, double total) throws SQLException, ClassNotFoundException, NamingException {
        int orderID = -1;
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(SAVETOORDER, Statement.RETURN_GENERATED_KEYS);
                ptm.setString(1, userID);
                ptm.setDouble(2, total);
                if (ptm.executeUpdate() > 0) {
                    rs = ptm.getGeneratedKeys();
                    if (rs.next()) {
                        orderID = rs.getInt(1);
                    }
                }
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ptm != null) {
                ptm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return orderID;
    }

    public int getQuantity(String comesticsID) throws ClassNotFoundException, SQLException, NamingException {
        int quantity = 0;
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(QUANTITY);
                ptm.setString(1, comesticsID);
                rs = ptm.executeQuery();
                if (rs.next()) {
                    quantity = rs.getInt("quantity");
                }
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ptm != null) {
                ptm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return quantity;
    }

    public boolean updateQuantity(String id, int newQuantity) throws ClassNotFoundException, SQLException, NamingException {
         boolean check = false;
        Connection conn = null;
        PreparedStatement ptm = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(UPDATE);
                ptm.setInt(1, newQuantity);
                ptm.setString(2, id);
                check = ptm.executeUpdate() > 0 ? true : false;
            }
        } finally {
            if (ptm != null) {
                ptm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return check;
    }
    

    public boolean SaveToOrderDetail(int orderID, String productID, double price, int quantity) throws ClassNotFoundException, SQLException, NamingException {
       boolean check = false;
        Connection conn = null;
        PreparedStatement ptm = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(SAVETOORDERDETAIL);
                ptm.setInt(1, orderID);
                ptm.setString(2, productID);
                ptm.setDouble(3, price);
                ptm.setInt(4, quantity);
                check = ptm.executeUpdate() > 0 ? true : false;
            }
        } finally {
            if (ptm != null) {
                ptm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return check;
    }
    
    
     
     
}
