/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sample.comestics.Cart;
import sample.comestics.Comestics;
import sample.comestics.ProductDAO;
import sample.user.UserDTO;

/**
 *
 * @author ASUS
 */
public class CheckoutController extends HttpServlet {

    private static final String ERROR= "confirmation.jsp";
    private static final String SUCCESS= "confirmation.jsp";
    private static final String ERROR_MESSAGE= "Your purchase help some issue";
    private static final String SUCCESS_MESSAGE= "Thanks for your purchase";
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url= ERROR;
        try {
            HttpSession session = request.getSession();
            ProductDAO product = new ProductDAO();
            Cart cart = (Cart) session.getAttribute("CART");
            UserDTO loginUser = (UserDTO) session.getAttribute("LOGIN_USER");
            double total= 0;
            for (Comestics comestics : cart.getCart().values()) {
                total += comestics.getPrice() * comestics.getQuantity();
               
            }
            int cnt = 0;
            if (loginUser != null && cart != null) {
                String userID = loginUser.getUserID();
                int orderID = product.saveToOrder(userID, total);
                for (Comestics cosmetics : cart.getCart().values()) {
                    String id = cosmetics.getId();
                    int quantity = cosmetics.getQuantity();
                    int warehouseQuantity = product.getQuantity(id);
                    int newQuantity = warehouseQuantity - quantity;
                    double price = cosmetics.getPrice();
                    
                    boolean checkUpdateQuantity = product.updateQuantity(id, newQuantity);
                    boolean checkOrderDetail = false;
                    if (orderID != -1) {
                        checkOrderDetail = product.SaveToOrderDetail(orderID, id, price, quantity);                    
                    }
                    if (checkUpdateQuantity && checkOrderDetail) {
                        cnt++;
                    }
                }
                    if (cnt >= 1) {
                        session.setAttribute("MESSAGE", SUCCESS_MESSAGE);
                        cart.clear();
                        url = SUCCESS;
                }
                    
                
            }else{
             session.setAttribute("MESSAGE", ERROR_MESSAGE);
        }
           
        }catch(Exception e) {
            log("Error at CheckoutController: " + e.toString());
        }finally { 
            response.sendRedirect(url);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
