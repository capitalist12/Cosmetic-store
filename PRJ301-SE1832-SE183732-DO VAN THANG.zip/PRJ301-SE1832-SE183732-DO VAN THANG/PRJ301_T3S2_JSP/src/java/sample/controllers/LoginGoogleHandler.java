/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample.controllers;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.fluent.Form;
import org.apache.http.client.fluent.Request;
import sample.user.Constants;
import sample.user.UserDAO;
import sample.user.UserDTO;
import sample.user.UserGoogleDTO;
import sample.utils.GoogleUtils;

/**
 *
 * @author ASUS
 */

public class LoginGoogleHandler extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException, NamingException {        
        response.setContentType("text/html;charset=UTF-8");
        String code = request.getParameter("code");
        if(code == null || code.isEmpty()) {
            RequestDispatcher dis= request.getRequestDispatcher("login.jsp");
            dis.forward(request, response);
        }else {
            try {
            GoogleUtils gg = new GoogleUtils();
            String accessToken = gg.getToken(code);
            UserGoogleDTO acc = gg.getUserInfo(accessToken);
            
            UserDAO dao= new UserDAO();
            String userID= gg.generateRandomName();
            String fullName= acc.getGiven_name();
            String email= acc.getEmail();
            String password= gg.generateRandomPassword();         
            String roleID= "US";
            String status="1";
            
            UserDTO existingUser = dao.checkLoginByEmail(email);
            if(existingUser != null) {
                HttpSession session= request.getSession();
                session.setAttribute("LOGIN_USER", existingUser);
                response.sendRedirect("user1.jsp");
            }else {
                boolean checkInsert= dao.insert(new UserDTO(userID, fullName, roleID, password, email, status));
                if(checkInsert) {
                    HttpSession session= request.getSession();
                    UserDTO newUser= new UserDTO(userID, fullName, roleID, password, email, status);
                     session.setAttribute("LOGIN_USER", newUser);
                     boolean checkSendMail= gg.sendMail(email, userID, password);
                     if(checkInsert) {
                     response.sendRedirect("MainController?action=LoginWithGoogel");
                     }
                     
                }else {
            request.setAttribute("ERROR", "Account creation failed");
            request.getRequestDispatcher("login.jsp").forward(request, response);
          }
            }
            
            
        }catch(Exception e) {
             log("Error at GoogleLoginServlet: " + e.toString());
        request.setAttribute("ERROR", "Google login failed");
        request.getRequestDispatcher("login.jsp").forward(request, response);
        }
        
        
        
        

        
  
        }
    }
    
        
        

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(LoginGoogleHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginGoogleHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NamingException ex) {
            Logger.getLogger(LoginGoogleHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(LoginGoogleHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginGoogleHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NamingException ex) {
            Logger.getLogger(LoginGoogleHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
