/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample.utils;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.fluent.Form;
import org.apache.http.client.fluent.Request;
import sample.user.Constants;
import sample.user.UserDAO;
import sample.user.UserDTO;
import sample.user.UserGoogleDTO;


/**
 *
 * @author ASUS
 */
public class GoogleUtils {
    
    private static final String CHARACTERS="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private static final int NAME_LENGTH=6;
    private static final int PASSWORD_LENGTH=10;
    private static final SecureRandom random= new SecureRandom();
    public final String from = "dt2005.26@gmail.com";
    
    
    
     public static String getToken(String code) throws ClientProtocolException, IOException {
        String response = Request.Post(Constants.GOOGLE_LINK_GET_TOKEN)
                .bodyForm(
                        Form.form()
       .add("client_id", Constants.GOOGLE_CLIENT_ID)
                        .add("client_secret", Constants.GOOGLE_CLIENT_SECRET)
                        .add("redirect_uri", Constants.GOOGLE_REDIRECT_URI)
                        .add("code", code)
                        .add("grant_type", Constants.GOOGLE_GRANT_TYPE)
                        .build()
                )
                .execute().returnContent().asString();

        JsonObject jobj = new Gson().fromJson(response, JsonObject.class);
        String accessToken = jobj.get("access_token").toString().replaceAll("\"", "");
        return accessToken;
    }
    
    public static UserGoogleDTO getUserInfo(final String accessToken) throws ClientProtocolException, IOException {
        String link = Constants.GOOGLE_LINK_GET_USER_INFO + accessToken;
        String response = Request.Get(link).execute().returnContent().asString();
        
        // Parse JSON response
        JsonObject jsonObject = new Gson().fromJson(response, JsonObject.class);

        // Create UserGoogleDTO object
        UserGoogleDTO userGoogleDTO = new UserGoogleDTO();
        userGoogleDTO.setId(getJsonStringValue(jsonObject, "id"));
        userGoogleDTO.setEmail(getJsonStringValue(jsonObject, "email"));
        userGoogleDTO.setVertified_email(jsonObject.get("verified_email").getAsBoolean());
        userGoogleDTO.setName(getJsonStringValue(jsonObject, "name"));
        userGoogleDTO.setGiven_name(getJsonStringValue(jsonObject, "given_name"));
        userGoogleDTO.setFamily_name(getJsonStringValue(jsonObject, "family_name"));
        userGoogleDTO.setPicture(getJsonStringValue(jsonObject, "picture"));

        return userGoogleDTO;
    }

    private static String getJsonStringValue(JsonObject jsonObject, String key) {
        return jsonObject.has(key) && !jsonObject.get(key).isJsonNull() ? jsonObject.get(key).getAsString() : null;
    }
    
    public static String generateRandomName() {
        StringBuilder sb= new StringBuilder(NAME_LENGTH);
        for (int i = 0; i < NAME_LENGTH; i++) {
            int randomIndex= random.nextInt(CHARACTERS.length());
            sb.append(CHARACTERS.charAt(randomIndex));
        }
        return sb.toString();
            
        }
    
    public static String generateRandomPassword() {
        StringBuilder sb= new StringBuilder(PASSWORD_LENGTH);
        for (int i = 0; i < PASSWORD_LENGTH; i++) {
            int randomIndex= random.nextInt(CHARACTERS.length());
            sb.append(CHARACTERS.charAt(randomIndex));
        }
        return sb.toString();
            
        }
    
    public boolean sendMail(String email, String userId, String password) {

        boolean check = false;

        String to = email;
        // Sender's email ID needs to be mentioned


        // Assuming you are sending email from localhost
        String host = "smtp.gmail.com";

        // Get system properties
        Properties properties = System.getProperties();

        // Setup mail server
        //  properties.setProperty("mail.smtp.host", host);
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");

        properties.put("mail.smtp.port", "587");

        // Get the default Session object. 
        Session session;

        session = Session.getInstance(properties,
                new javax.mail.Authenticator() {

            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, "ctvrnjbshazzjvjr");
            }
        });

        session.setDebug(true);

        

        try {
            // Create a default MimeMessage object.
            MimeMessage message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(from));

            // Set To: header field of the header.
            message.addRecipient(Message.RecipientType.TO,
                    new InternetAddress(to));

            // Set Subject: header field
            message.setSubject("Your userID and password ");

            // Now set the actual message
            message.setText("UserID: " + userId +
                            "\nPassword: " + password);

            // Send message
            Transport.send(message);
            System.out.println("Sent message successfully....");

        } catch (MessagingException mex) {
            mex.printStackTrace();
        }

        return check;

    }
    
    
    
    
}

    

