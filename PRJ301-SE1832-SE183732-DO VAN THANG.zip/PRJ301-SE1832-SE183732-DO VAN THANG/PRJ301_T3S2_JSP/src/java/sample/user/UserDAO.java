/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NamingException;
import sample.utils.DBUtils;

/**
 *
 * @author admin
 */
public class UserDAO {
    
    private static final String LOGIN = "SELECT fullName, roleID, email, status FROM tblUSers WHERE userID = ? AND password = ?";
    private static final String LOGIN_EMAIL = "SELECT userID, fullName, password, roleID, status FROM tblUSers WHERE email = ? ";
    private static final String SEARCH = "SELECT userID, fullName, roleID, email, status FROM tblUsers WHERE fullName LIKE ?";
    private static final String SEARCH_EMAIL = "SELECT userID, password  FROM tblUsers WHERE email=?";
    private static final String DELETE = "DELETE tblUsers WHERE userID=?";
    private static final String UPDATE = "UPDATE tblUsers SET fullName=?, roleID=?, email=? WHERE userID=? ";
    private static String CHECK_DUPELICATE = "SELECT fullName FROM tblUsers WHERE email=?";
    private static String INSERT = "INSERT INTO tblUsers(userID, fullName, email, password, roleID, status) VALUES(?,?,?,?,?,?)";
    private static final String TOP1 = "SELECT TOP 1 userID, fullName FROM tblUsers ";
    
    

    public UserDTO checkLogin(String userID, String password) throws SQLException, ClassNotFoundException, NamingException {
        UserDTO user = null;
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(LOGIN);
                ptm.setString(1, userID);
                ptm.setString(2, password);
                rs = ptm.executeQuery();
                if (rs.next()) {
                    String fullName = rs.getString("fullName");
                    String roleID = rs.getString("roleID");
                    String email  = rs.getString("email");
                     String status  = rs.getString("status");
                    
                    user = new UserDTO(userID, fullName, roleID, password, email, status);
                }
            } 
         
        } finally {
            if (rs != null) rs.close();
            if (ptm != null) ptm.close();
            if (conn != null) conn.close();
        }
        return user;
    }
    
    public UserDTO checkLoginByEmail(String email) throws SQLException, ClassNotFoundException, NamingException {
        UserDTO user = null;
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(LOGIN_EMAIL);
                ptm.setString(1, email);
               
                rs = ptm.executeQuery();
                if (rs.next()) {
                    String userID = rs.getString("userID");
                    String fullName = rs.getString("fullName");
                    String password = rs.getString("password");
                    String roleID = rs.getString("roleID");
                    String status = rs.getString("status");
                    
                    user = new UserDTO(userID, fullName, roleID, password, email, status);
                }
            } 
         
        } finally {
            if (rs != null) rs.close();
            if (ptm != null) ptm.close();
            if (conn != null) conn.close();
        }
        return user;
    }
     public UserDTO getUserEmail(String email) throws SQLException, ClassNotFoundException, NamingException {
        UserDTO user = null;
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(SEARCH_EMAIL);
                ptm.setString(1, email);              
                rs = ptm.executeQuery();
                if (rs.next()) {
                    String userID = rs.getString("userID");
                    String password = rs.getString("password");                                        
                    user = new UserDTO(userID,"","", password, "", "");
                }
            } 
         
        } finally {
            if (rs != null) rs.close();
            if (ptm != null) ptm.close();
            if (conn != null) conn.close();
        }
        return user;
    }

    public List<UserDTO> getListUser(String search) throws SQLException, ClassNotFoundException, NamingException {
        List<UserDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(SEARCH);
                ptm.setString(1, "%" + search +"%");
                rs = ptm.executeQuery();
                while (rs.next()) {
                    String userID = rs.getString("userID");
                    String fullName = rs.getString("fullName");
                    String roleID = rs.getString("roleID");
                    String password = "*****";
                    String email = rs.getString("email");
                    String status = rs.getString("status");
                    list.add(new UserDTO(userID, fullName, roleID, password, email, status));
                }
            }        
        } finally {
            if (rs != null) rs.close();
            if (ptm != null) ptm.close();
            if (conn != null) conn.close();      
        }
        return list;
    }

    public boolean delete(String userID) throws SQLException, ClassNotFoundException, NamingException {
        boolean check = false;
        Connection conn = null;
        PreparedStatement ptm = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(DELETE);
                ptm.setString(1, userID);
                check = ptm.executeUpdate() > 0 ? true : false;
            }       
        } finally {
            if (ptm != null) ptm.close();
            if (conn != null) conn.close();     
        }
        return check;
    }
    
    public boolean updateUser(UserDTO user) throws SQLException, ClassNotFoundException, NamingException {
        boolean check = false;
        Connection conn = null;
        PreparedStatement ptm = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(UPDATE);
              
                ptm.setString(1, user.getFullName());
                ptm.setString(2, user.getRoleID());
                ptm.setString(3, user.getEmail());
                ptm.setString(4, user.getUserID());
             
                check = ptm.executeUpdate() > 0 ? true : false;
            }       
        } finally {
            if (ptm != null) ptm.close();
            if (conn != null) conn.close();     
        }
        return check;
    }

    public boolean insert(UserDTO user) throws SQLException, ClassNotFoundException, NamingException{
        boolean check = false;
        Connection con = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try{
            con = DBUtils.getConnection();
            if(con != null){
                ptm = con.prepareStatement(INSERT);
                ptm.setString(1, user.getUserID());
                ptm.setString(2, user.getFullName());
                ptm.setString(3, user.getEmail());
                ptm.setString(4, user.getPassword());
                ptm.setString(5, user.getRoleID());
                ptm.setString(6, user.getStatus());
                check = ptm.executeUpdate() > 0 ? true : false;
            }
        }finally{
            if(ptm != null){
                ptm.close();
            }
            if(con != null){
                con.close();
            }
            if(rs != null){
                rs.close();
            }
        }
        return check;
    }
    public boolean checkDupelicate(String email) throws SQLException, ClassNotFoundException, NamingException{
        boolean check = false;
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try{
            con = DBUtils.getConnection();
            if(con != null){
                stm = con.prepareStatement(CHECK_DUPELICATE);
                stm.setString(1, email);
                rs = stm.executeQuery();
                if(rs.next()){
                    check = true;
                }
            }
        }finally{
            if(stm != null){
                stm.close();
            }
            if(con != null){
                con.close();
            }
            if(rs != null){
                rs.close();
            }
        }
        return check;
    }
    
    
    public Top1UserDTO getTop1user() throws SQLException, ClassNotFoundException, NamingException {
        Top1UserDTO user = null;
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ptm = conn.prepareStatement(TOP1);              
                rs = ptm.executeQuery();
                if (rs.next()) {
                    String userID = rs.getString("userID");
                    String fullName = rs.getString("fullName");                  
                    
                    user = new Top1UserDTO(userID, fullName);
                }
            } 
         
        } finally {
            if (rs != null) rs.close();
            if (ptm != null) ptm.close();
            if (conn != null) conn.close();
        }
        return user;
    }
    
    
}
