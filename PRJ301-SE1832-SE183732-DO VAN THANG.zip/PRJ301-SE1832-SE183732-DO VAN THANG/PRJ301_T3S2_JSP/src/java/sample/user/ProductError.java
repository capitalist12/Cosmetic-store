/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample.user;

/**
 *
 * @author ASUS
 */
public class ProductError {
    private String idError;
    private String nameError;
    private String quantityError;
    private String priceError;
    private String error;

    public ProductError() {
    }

    public ProductError(String idError, String nameError, String quantityError, String priceError, String error) {
        this.idError = idError;
        this.nameError = nameError;
        this.quantityError = quantityError;
        this.priceError = priceError;
        this.error = error;
    }

    public String getIdError() {
        return idError;
    }

    public void setIdError(String idError) {
        this.idError = idError;
    }

    public String getNameError() {
        return nameError;
    }

    public void setNameError(String nameError) {
        this.nameError = nameError;
    }

    public String getQuantityError() {
        return quantityError;
    }

    public void setQuantityError(String quantityError) {
        this.quantityError = quantityError;
    }

    public String getPriceError() {
        return priceError;
    }

    public void setPriceError(String priceError) {
        this.priceError = priceError;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    
}
